const express = require('express');
const router = express.Router();
require('dotenv').config();
const Orders = require('../../models/Orders/Orders');
const SpecialOrders = require('../../models/Orders/SpecialOrder');

const mongoose = require('mongoose');

const { tokenGenerator, logout , maxAgeAccessToken} = require('../../helpers/authentication');

const User = require("../../models/Users/User")



const createToken= (user)=>{
    return {
        ACCESS_TOKEN: tokenGenerator({user},process.env.ACCESS_TOKEN_SECRET),
        }
}
//############################# LOGOUT ##########################################""""


router.delete('/logout',logout,(req, res)=>{
    console.log(req.cookies)
    res.json({status:"logout sucess"});

});

//############################# LOGIN ##########################################""""

router.post('/login',async (req, res)=>{
    console.log(req.body);
    const { email, password} =  req.body;
    try
    {
      const user = await User.login(email, password);
      if(user && mongoose.Types.ObjectId.isValid(user._id))
        {
            const token = createToken(user).ACCESS_TOKEN;
                res.cookie("accessjwt", token, {maxAge:maxAgeAccessToken*1000})
                const orders={};
                Orders.find({user:user._id}).then(result=>{
                    orders.normal = result
                });
                SpecialOrders.find({user:user._id}).then(result=>{
                    orders.special = result
                })
                res.status(200).json({user:user._id, username: user.username, email:user.email,accessToken: token})
                 
        }
        else
        {
            res.status(401).json({"error":"Invalid user account"})
        }
    }
    catch (error)
    {
        res.status(405).json({err:error.toString()})
    }
});


//############################# SIGNUP ##########################################""""

router.post("/sign-up",(req,res)=>{
    console.log("from front end", req)
    try
    {
        const newUser = new User({
            username: req.body.username,
            email:req.body.email,
            telephone: req.body.telephone,
            password: req.body.password
        });

        newUser.save().then(user=>{
            const token = createToken(user).ACCESS_TOKEN;
            const userTokens ={accessToken: token};
            res.cookie("accessjwt", token, {maxAge:maxAgeAccessToken*1000, path:"/",});
            res.status(200).json({user:user._id, username:user.username, email:user.email, role: user.role,...userTokens});

        }).catch(err=>{
            console.log(err)
            if(err.code === 11000){
                const error = Error(` ${Object.keys(err.keyValue)}  d'utilisateur ${err.keyValue[Object.keys(err.keyValue)[0]]} non disponible`);
                res.status(404).json({err: error.message.toString(), success: false});
            }
           
        });
    }
    catch (error)
    {
        res.status(401).json({err:error.toString()});
    }

});



router.get("/users",(req,res)=>{
    try
    {
        User.find({})
            .then(users=>{
                    res.status(200).json(users);
                }).catch(err=>{
                    res.status(400).json(err);
                });
    }
    catch (error)
    {
        res.status(400).json({err:error.toString()});
    }

});
router.post("/user/edit/:user_id",(req,res)=>{
    console.log(res.body)
    try
    {
      User.findOneAndUpdate({_id:req.params.user_id}, {$set:{password: req.body.newPassword }}).exec(function(err, user){
        if(err) {
            res.status(500).send(err);
        } else {
            res.status(200).send({user, success:true});
        }
     });
    }
    catch (error)
    {
        res.status(400).json({err:error.toString()});
    }

});



// password reset



module.exports = router;
